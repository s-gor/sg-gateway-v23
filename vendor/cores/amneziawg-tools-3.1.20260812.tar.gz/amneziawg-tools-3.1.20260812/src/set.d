set.o: set.c containers.h type.h uapi/linux/linux/wireguard.h config.h \
 ipc.h subcommands.h
containers.h:
type.h:
uapi/linux/linux/wireguard.h:
config.h:
ipc.h:
subcommands.h:
