showconf.o: showconf.c containers.h type.h uapi/linux/linux/wireguard.h \
 encoding.h ipc.h subcommands.h
containers.h:
type.h:
uapi/linux/linux/wireguard.h:
encoding.h:
ipc.h:
subcommands.h:
