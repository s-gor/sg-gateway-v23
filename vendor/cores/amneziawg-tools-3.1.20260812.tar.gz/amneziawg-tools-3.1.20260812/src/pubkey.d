pubkey.o: pubkey.c curve25519.h encoding.h containers.h type.h \
 uapi/linux/linux/wireguard.h subcommands.h ctype.h
curve25519.h:
encoding.h:
containers.h:
type.h:
uapi/linux/linux/wireguard.h:
subcommands.h:
ctype.h:
