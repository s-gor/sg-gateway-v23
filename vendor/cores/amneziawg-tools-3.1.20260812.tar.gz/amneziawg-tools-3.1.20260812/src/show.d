show.o: show.c containers.h type.h uapi/linux/linux/wireguard.h ipc.h \
 terminal.h encoding.h subcommands.h
containers.h:
type.h:
uapi/linux/linux/wireguard.h:
ipc.h:
terminal.h:
encoding.h:
subcommands.h:
