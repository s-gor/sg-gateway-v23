ipc.o: ipc.c containers.h type.h uapi/linux/linux/wireguard.h ipc.h \
 ipc-uapi.h curve25519.h encoding.h ctype.h ipc-uapi-unix.h ipc-linux.h \
 netlink.h uapi/linux/linux/wireguard.h
containers.h:
type.h:
uapi/linux/linux/wireguard.h:
ipc.h:
ipc-uapi.h:
curve25519.h:
encoding.h:
ctype.h:
ipc-uapi-unix.h:
ipc-linux.h:
netlink.h:
uapi/linux/linux/wireguard.h:
