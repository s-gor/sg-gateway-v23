config.o: config.c config.h containers.h type.h \
 uapi/linux/linux/wireguard.h ipc.h encoding.h ctype.h
config.h:
containers.h:
type.h:
uapi/linux/linux/wireguard.h:
ipc.h:
encoding.h:
ctype.h:
