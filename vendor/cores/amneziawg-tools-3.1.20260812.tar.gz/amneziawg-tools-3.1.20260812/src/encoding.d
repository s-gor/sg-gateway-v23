encoding.o: encoding.c encoding.h containers.h type.h \
 uapi/linux/linux/wireguard.h
encoding.h:
containers.h:
type.h:
uapi/linux/linux/wireguard.h:
